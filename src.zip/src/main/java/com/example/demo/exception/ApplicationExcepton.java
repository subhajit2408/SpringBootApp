package com.example.demo.exception;

public class ApplicationExcepton extends RuntimeException {
    public ApplicationExcepton(String message){
        super(message);
    }
}
