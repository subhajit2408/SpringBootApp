package com.example.demo.exception;

import org.hibernate.exception.JDBCConnectionException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ApplicationExceptionHandler {

    @ExceptionHandler({ApplicationExcepton.class, JDBCConnectionException.class, DataAccessResourceFailureException.class})
    public String handleException(){
        System.out.println("In Global exception handler!!");
        return "error";
    }
}
