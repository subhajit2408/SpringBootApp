package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RedirectionController {

    @GetMapping("/redirectToLinkedIn")
    public String redirectToLinkedIn(){
        System.out.println("Inside redirection controller!!");

        return "redirect:http://www.linkedin.com";
    }
}
