package com.example.demo.controller;

import com.example.demo.bean.Login;
import com.example.demo.bean.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class HomeController {

    @GetMapping("/home")
    public String goHome(){
        System.out.println("Inside home controller!!");
        return "index";
    }

    @GetMapping("/goToSearch")
    public String goToSearch(){
        System.out.println("Go to search page!!!!");
        return "search";
    }

    @GetMapping("/goToLogin")
    public String goToLogin(){
        System.out.println("Go to login page!!!!");
        return "login";
    }

    @GetMapping("/goToRegistration")
            public String goToRegistration(){
            System.out.println("Go to registration page!!!!");
            return "register";
            }


   /* @ModelAttribute("getGenderItems")
    public List<String> getGenderItems(){
        List<String> list = new ArrayList<>();
        list.add("MALE");
        list.add("FEMALE");
        list.add("OTHER");
        return list;
    }*/
}
