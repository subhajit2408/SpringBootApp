package com.example.demo.controller;

import com.example.demo.bean.Login;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
public class UserProfileController {

    @PostMapping("/userprofile")
    public String getUserProfile(@SessionAttribute("login") Login login, Model model){
        System.out.println("Inside profile controller!!");
        System.out.println("User name from session object:"+login.getUname());
        model.addAttribute("username",login.getUname());
        return "profile";
    }
}
