package com.example.demo.controller;

import com.example.demo.bean.Login;
import com.example.demo.bean.User;
import com.example.demo.exception.ApplicationExcepton;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("login")
public class LoginController {

    @Autowired
    public UserRepository userRepository;

    @PostMapping("/login")
    public String login(@ModelAttribute("login") Login login){
        User user = userRepository.searchByName(login.getUname());
        if(user == null){
            throw new ApplicationExcepton("User doesn't exists!!");
        }
        return "forward:/userprofile";
    }

    /*@ExceptionHandler(ApplicationExcepton.class)
    public String handleException(){
        System.out.println("Handeling Application exception!!");
        return "error";
    }*/
}
