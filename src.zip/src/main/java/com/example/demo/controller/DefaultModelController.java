package com.example.demo.controller;

import com.example.demo.bean.Login;
import com.example.demo.bean.User;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class DefaultModelController {

    @ModelAttribute("newuser")
    public User getDefaultUser(){
        return new User();
    }
    @ModelAttribute("login")
    public Login getDefaultLogin(){
        return new Login();
    }
}
